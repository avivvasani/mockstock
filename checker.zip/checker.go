package main

import (
	"encoding/csv"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
)

type FileResult struct {
	Rank     int     `json:"rank"`
	Name     string  `json:"name"`
	TotalPL  float64 `json:"total_profit_loss"`
}

func main() {
	// 1. Find all .csv files
	files, err := filepath.Glob("*.csv")
	if err != nil || len(files) == 0 {
		fmt.Println("No CSV files found in the directory. Exiting.")
		return
	}

	var results []FileResult

	// 2. Process each file
	for _, path := range files {
		file, err := os.Open(path)
		if err != nil {
			continue
		}

		reader := csv.NewReader(file)
		// Skip header
		if _, err := reader.Read(); err != nil {
			file.Close()
			continue
		}

		var fileTotal float64
		for {
			record, err := reader.Read()
			if err == io.EOF {
				break
			}
			// Skip empty rows or summary rows (like in image_5b305a.png)
			if err != nil || len(record) < 6 || record[0] == "" || strings.Contains(record[0], "Total") {
				break
			}

			val, _ := strconv.ParseFloat(record[5], 64)
			fileTotal += val
		}
		file.Close()

		// Strip the path and the .csv extension
		cleanName := strings.TrimSuffix(filepath.Base(path), ".csv")

		results = append(results, FileResult{
			Name:    cleanName,
			TotalPL: fileTotal,
		})
	}

	// 3. Sort by Total Profit/Loss (descending)
	sort.Slice(results, func(i, j int) bool {
		return results[i].TotalPL > results[j].TotalPL
	})

	// 4. Assign Rank
	for i := range results {
		results[i].Rank = i + 1
	}

	// 5. Save to tpl.json
	jsonData, _ := json.MarshalIndent(results, "", "  ")
	err = os.WriteFile("tpl.json", jsonData, 0644)
	
	if err != nil {
		fmt.Printf("Error: %v\n", err)
	} else {
		fmt.Printf("Ranked %d users in tpl.json\n", len(results))
	}
}